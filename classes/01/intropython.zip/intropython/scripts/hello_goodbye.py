#!/usr/bin/env python
"""
Simple program that prints 'Hello, world!'.

"""

def hello():
    """Greets the user"""
    print("Hey there!")

def bye():
    """A sad goodbye"""
    print("I hope this isn't goodbye!")

def main():
    """hello goodbye"""
    hello()
    bye()

if __name__ == "__main__":
    main()
